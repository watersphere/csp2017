<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Home</title>
  </head>
  <body>
    <a href="index.html">Home</a>
    <a href="portfolio.html">Portfolio</a>
    <h1>This is my test Home Page!</h1>
    <img src="images/home.jpg" height="250">
  </body>
</html>